"""Hard reservation accounting shared by all external providers."""

from __future__ import annotations

import hashlib
import json
from collections import Counter
from collections.abc import Callable, Iterable, Mapping
from datetime import UTC, datetime, timedelta
from decimal import Decimal
import threading
from typing import Literal
from uuid import uuid4

from paper_search.domain.models import (
    BudgetReservation,
    SearchBudget,
    UsageActual,
    UsageEstimate,
)


from paper_search.errors import ProtectedExecutionError


class BudgetExceededError(ProtectedExecutionError):
    """Raised before an operation that would exceed a hard limit."""

    search_error_code = "budget_exhausted"


class ReservationError(ProtectedExecutionError):
    """Raised when a reservation is invalid or cannot be settled safely."""


Clock = Callable[[], datetime]
TerminalMode = Literal["settled", "failed"]
TerminalRecord = tuple[
    BudgetReservation,
    TerminalMode,
    UsageActual,
    tuple[UsageActual, ...],
]
CommittedProvenance = tuple[BudgetReservation, TerminalMode, int] | None


def _aggregate(usages: Iterable[UsageEstimate]) -> UsageEstimate:
    items = list(usages)
    costs = [item.cost_cny for item in items]
    known_costs = [value for value in costs if value is not None]
    cost = sum(known_costs) if costs and len(known_costs) == len(costs) else None
    return UsageEstimate(
        search_api_calls=sum(item.search_api_calls for item in items),
        llm_calls=sum(item.llm_calls for item in items),
        input_tokens=sum(item.input_tokens for item in items),
        cached_input_tokens=sum(item.cached_input_tokens for item in items),
        uncached_input_tokens=sum(item.uncached_input_tokens for item in items),
        output_tokens=sum(item.output_tokens for item in items),
        cost_cny=cost,
        elapsed_ms=sum(item.elapsed_ms for item in items),
    )


def _known_cost(usages: Iterable[UsageEstimate]) -> Decimal:
    return sum(
        (item.cost_cny for item in usages if item.cost_cny is not None),
        Decimal("0"),
    )


def _committed_component_key(
    action: str,
    usage: UsageActual,
    provenance: CommittedProvenance,
) -> tuple[str, str, str, TerminalMode, int]:
    """Return the exact immutable identity of one receipted commitment."""

    if provenance is None:
        raise ValueError("unreceipted usage has no terminal component key")
    reservation, mode, component_index = provenance
    return (
        action,
        usage.model_dump_json(),
        reservation.model_dump_json(),
        mode,
        component_index,
    )


class HardBudgetController:
    """Reserve estimates before calls and replace them with actual usage after calls.

    Expiry handling, persistence, soft deadlines and concurrent atomic reservation are
    deliberately deferred to Task 7. This Task 1 controller enforces hard limits in one
    process and prevents a caller from settling more usage than it reserved.
    """

    def __init__(
        self,
        budget: SearchBudget,
        *,
        reservation_ttl_seconds: int = 120,
        clock: Clock | None = None,
        formal_live: bool = False,
    ) -> None:
        if reservation_ttl_seconds <= 0:
            raise ValueError("reservation_ttl_seconds must be positive")
        self._budget = SearchBudget.model_validate(budget.model_dump())
        self.reservation_ttl_seconds = reservation_ttl_seconds
        self.formal_live = formal_live
        self._clock = clock or (lambda: datetime.now(UTC))
        self._lock = threading.RLock()
        self._reservations: dict[str, BudgetReservation] = {}
        self._expired_reservations: dict[str, BudgetReservation] = {}
        self._dispatched_reservations: set[str] = set()
        self._committed: list[UsageActual] = []
        self._committed_actions: list[str] = []
        self._committed_provenance: list[CommittedProvenance] = []
        self._terminal_outcomes: dict[str, TerminalRecord] = {}
        self._fail_closed = False

    @property
    def budget(self) -> SearchBudget:
        return self._budget

    @property
    def policy_fingerprint(self) -> str:
        """Hash every immutable setting that changes hard-budget enforcement."""
        content = json.dumps(
            {
                "identity_schema_version": "hard-budget-enforcement-identity-v1",
                "controller_version": "hard-budget-controller-v1",
                "budget": self._budget.model_dump(mode="json"),
                "formal_live": self.formal_live,
                "reservation_ttl_seconds": self.reservation_ttl_seconds,
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return "sha256:" + hashlib.sha256(content).hexdigest()

    @property
    def reserved_usage(self) -> UsageEstimate:
        with self._lock:
            self._expire_locked()
            return _aggregate(item.reserved for item in self._reservations.values())

    @property
    def committed_usage(self) -> UsageActual:
        with self._lock:
            summary = _aggregate(self._committed)
            return UsageActual.model_validate(summary.model_dump())

    @property
    def known_committed_cost_cny(self) -> Decimal:
        with self._lock:
            return _known_cost(self._committed)

    @property
    def unknown_cost_actions(self) -> list[str]:
        with self._lock:
            return [
                action
                for action, usage in zip(self._committed_actions, self._committed, strict=True)
                if usage.cost_cny is None
            ]

    def reserve(self, action: str, estimate: UsageEstimate) -> BudgetReservation:
        with self._lock:
            self._expire_locked()
            if self.stop_status() == "hard_stop":
                raise BudgetExceededError("budget controller is in hard-stop state")
            if estimate.llm_calls > 0 and estimate.cost_cny is None:
                raise ReservationError("LLM reservations require a known cost estimate")
            candidate = [
                *self._committed,
                *(r.reserved for r in self._reservations.values()),
                estimate,
            ]
            self._check_hard_limits(candidate)
            reservation = BudgetReservation(
                reservation_id=str(uuid4()),
                action=action,
                reserved=estimate,
                expires_at=self._clock() + timedelta(seconds=self.reservation_ttl_seconds),
            )
            self._reservations[reservation.reservation_id] = reservation
            return reservation

    def can_reserve(self, estimate: UsageEstimate) -> bool:
        """Return whether an estimate currently fits without creating a reservation."""
        with self._lock:
            self._expire_locked()
            if self.stop_status() == "hard_stop":
                return False
            if estimate.llm_calls > 0 and estimate.cost_cny is None:
                raise ReservationError("LLM reservations require a known cost estimate")
            candidate = [
                *self._committed,
                *(item.reserved for item in self._reservations.values()),
                estimate,
            ]
            try:
                self._check_hard_limits(candidate)
            except BudgetExceededError:
                return False
            return True

    def settle(self, reservation: BudgetReservation, actual: UsageActual) -> None:
        with self._lock:
            self._expire_locked()
            actual = UsageActual.model_validate(actual.model_dump(mode="python"))
            active = self._reservations.get(reservation.reservation_id)
            if active is None:
                raise ReservationError("reservation is unknown or already settled")
            if active != reservation:
                raise ReservationError("reservation does not match the active reservation")
            if self.formal_live and actual.cost_cny is None:
                raise ReservationError("formal live settlement requires a valued actual cost")
            self._ensure_within_reservation(active.reserved, actual)

            other_reserved = [
                item.reserved
                for reservation_id, item in self._reservations.items()
                if reservation_id != reservation.reservation_id
            ]
            self._check_hard_limits([*self._committed, *other_reserved, actual])
            del self._reservations[reservation.reservation_id]
            self._dispatched_reservations.discard(reservation.reservation_id)
            self._committed.append(actual)
            self._committed_actions.append(active.action)
            self._committed_provenance.append((active, "settled", 0))
            self._terminal_outcomes[reservation.reservation_id] = (
                active,
                "settled",
                actual,
                (actual,),
            )

    def terminal_outcome(
        self,
        reservation: BudgetReservation,
    ) -> tuple[TerminalMode, UsageActual] | None:
        """Return an exact terminal receipt without inferring from exceptions."""

        with self._lock:
            record = self._terminal_outcomes.get(reservation.reservation_id)
            if record is None:
                return None
            stored, mode, actual, _ = record
            if stored != reservation:
                raise ReservationError(
                    "reservation does not match the terminal reservation"
                )
            return mode, UsageActual.model_validate(actual.model_dump(mode="python"))

    def release(self, reservation: BudgetReservation) -> None:
        """Release an unused active reservation."""
        with self._lock:
            self._expire_locked()
            if reservation.reservation_id in self._dispatched_reservations:
                dispatched = self._reservations.get(
                    reservation.reservation_id
                ) or self._expired_reservations.get(reservation.reservation_id)
                if dispatched == reservation:
                    raise ReservationError(
                        "dispatched reservation cannot be released"
                    )
            active = self._reservations.get(reservation.reservation_id)
            if active != reservation:
                raise ReservationError("reservation is unknown or does not match the active reservation")
            del self._reservations[reservation.reservation_id]
            self._dispatched_reservations.discard(reservation.reservation_id)

    def mark_dispatched(self, reservation: BudgetReservation) -> None:
        """Retain terminal authority only after an external call is dispatched."""

        with self._lock:
            self._expire_locked()
            active = self._reservations.get(reservation.reservation_id)
            if active != reservation:
                raise ReservationError(
                    "reservation is unknown or does not match the active reservation"
                )
            self._dispatched_reservations.add(reservation.reservation_id)

    def expire_reservations(self) -> list[str]:
        """Release expired reservations and return their stable IDs."""
        with self._lock:
            return self._expire_locked()

    def fail_closed(
        self,
        reservation: BudgetReservation,
        actual: UsageActual | None = None,
    ) -> None:
        """Atomically hard-stop and optionally commit terminal measured usage.

        The one-argument form retains the original behavior for callers that do not
        possess terminal usage. The two-argument form is the authoritative terminal
        transition: dispatched usage is committed even when its cost is unknown or it
        exceeds the reservation, because the controller is hard-stopped at the same time.
        """
        with self._lock:
            active = self._terminal_reservation_locked(reservation)
            self._fail_closed = True
            if actual is None:
                return
            self._commit_terminal_locked(active, [actual])

    def fail_closed_attempts(
        self,
        reservation: BudgetReservation,
        actuals: Iterable[UsageActual],
    ) -> None:
        """Atomically hard-stop and retain priced and unpriced terminal attempts."""

        committed = [
            UsageActual.model_validate(actual.model_dump(mode="python"))
            for actual in actuals
        ]
        if not committed:
            raise ReservationError("terminal settlement requires actual usage")
        with self._lock:
            active = self._terminal_reservation_locked(reservation)
            self._fail_closed = True
            self._commit_terminal_locked(active, committed)

    def _terminal_reservation_locked(
        self, reservation: BudgetReservation
    ) -> BudgetReservation:
        active = self._reservations.get(reservation.reservation_id)
        expired = self._expired_reservations.get(reservation.reservation_id)
        terminal = active if active is not None else expired
        if terminal != reservation:
            raise ReservationError(
                "reservation is unknown or does not match the active reservation"
            )
        return terminal

    def _commit_terminal_locked(
        self,
        reservation: BudgetReservation,
        actuals: Iterable[UsageActual],
    ) -> None:
        committed = [
            UsageActual.model_validate(actual.model_dump(mode="python"))
            for actual in actuals
        ]
        self._reservations.pop(reservation.reservation_id, None)
        self._expired_reservations.pop(reservation.reservation_id, None)
        self._dispatched_reservations.discard(reservation.reservation_id)
        self._committed.extend(committed)
        self._committed_actions.extend(reservation.action for _ in committed)
        self._committed_provenance.extend(
            (reservation, "failed", index) for index in range(len(committed))
        )
        aggregate = UsageActual.model_validate(_aggregate(committed).model_dump())
        self._terminal_outcomes[reservation.reservation_id] = (
            reservation,
            "failed",
            aggregate,
            tuple(committed),
        )

    def stop_status(self) -> str:
        """Return deterministic continue, soft-stop, or hard-stop state."""
        with self._lock:
            self._expire_locked()
            if self._fail_closed:
                return "hard_stop"
            total = _aggregate([*self._committed, *(r.reserved for r in self._reservations.values())])
            hard = (
                total.search_api_calls >= self._budget.max_search_api_calls
                or total.llm_calls >= self._budget.max_llm_calls
                or total.input_tokens + total.output_tokens >= self._budget.max_total_tokens
                or total.elapsed_ms >= self._budget.max_elapsed_seconds * 1000
                or _known_cost([*self._committed, *(r.reserved for r in self._reservations.values())])
                >= self._budget.max_cost_cny
            )
            if hard:
                return "hard_stop"
            if total.elapsed_ms >= self._budget.soft_deadline_seconds * 1000:
                return "soft_stop"
            return "continue"

    def export_state(self) -> dict[str, object]:
        """Return JSON-round-trippable reservation and committed usage state."""
        with self._lock:
            self._expire_locked()
            return {
                "version": 4,
                "reservation_ttl_seconds": self.reservation_ttl_seconds,
                "formal_live": self.formal_live,
                "fail_closed": self._fail_closed,
                "reservations": [item.model_dump(mode="json") for item in self._reservations.values()],
                "expired_reservations": [
                    item.model_dump(mode="json")
                    for item in self._expired_reservations.values()
                ],
                "dispatched_reservation_ids": sorted(
                    self._dispatched_reservations
                ),
                "committed": [
                    {
                        "action": action,
                        "usage": usage.model_dump(mode="json"),
                        "reservation": (
                            provenance[0].model_dump(mode="json")
                            if provenance is not None
                            else None
                        ),
                        "mode": provenance[1] if provenance is not None else None,
                        "component_index": (
                            provenance[2] if provenance is not None else None
                        ),
                    }
                    for action, usage, provenance in zip(
                        self._committed_actions,
                        self._committed,
                        self._committed_provenance,
                        strict=True,
                    )
                ],
                "terminal_outcomes": [
                    {
                        "reservation": reservation.model_dump(mode="json"),
                        "action": reservation.action,
                        "mode": mode,
                        "actual": actual.model_dump(mode="json"),
                        "components": [
                            component.model_dump(mode="json")
                            for component in components
                        ],
                    }
                    for reservation, mode, actual, components in self._terminal_outcomes.values()
                ],
                "terminal_outcomes_complete": all(
                    provenance is not None
                    for provenance in self._committed_provenance
                ),
            }

    @classmethod
    def from_state(
        cls,
        budget: SearchBudget,
        state: Mapping[str, object],
        *,
        clock: Clock | None = None,
    ) -> HardBudgetController:
        """Restore validated state without bypassing budget accounting invariants."""
        version = state.get("version")
        if type(version) is not int or version not in {1, 2, 3, 4}:
            raise ValueError("invalid budget controller state version")

        reservation_ttl_seconds = state.get("reservation_ttl_seconds")
        fail_closed = state.get("fail_closed")
        # Version 1 predates formal-live settlement.  States created during
        # the transition may contain a strict boolean flag, which is retained
        # so formal-live state cannot be silently downgraded on recovery.
        if version == 1:
            formal_live = state.get("formal_live", False)
        else:
            if "formal_live" not in state:
                raise ValueError("invalid budget controller state formal_live")
            formal_live = state["formal_live"]
        if not isinstance(formal_live, bool):
            raise ValueError("invalid budget controller state formal_live")
        if type(reservation_ttl_seconds) is not int or not isinstance(fail_closed, bool):
            raise ValueError("invalid budget controller state")
        controller = cls(
            budget,
            reservation_ttl_seconds=reservation_ttl_seconds,
            clock=clock,
            formal_live=formal_live,
        )
        reservations = state.get("reservations")
        expired_reservations = (
            state.get("expired_reservations") if version in {3, 4} else []
        )
        dispatched_reservation_ids = (
            state.get("dispatched_reservation_ids") if version in {3, 4} else None
        )
        committed = state.get("committed")
        terminal_outcomes = state.get("terminal_outcomes") if version == 4 else []
        terminal_outcomes_complete = state.get("terminal_outcomes_complete", False)
        if (
            not isinstance(reservations, list)
            or not isinstance(expired_reservations, list)
            or (
                version in {3, 4}
                and not isinstance(dispatched_reservation_ids, list)
            )
            or not isinstance(committed, list)
            or not isinstance(terminal_outcomes, list)
            or not isinstance(terminal_outcomes_complete, bool)
        ):
            raise ValueError("invalid budget controller state")
        try:
            restored_reservations = [BudgetReservation.model_validate(raw) for raw in reservations]
            restored_expired = [
                BudgetReservation.model_validate(raw) for raw in expired_reservations
            ]
            all_reservations = [*restored_reservations, *restored_expired]
            if len({item.reservation_id for item in all_reservations}) != len(
                all_reservations
            ):
                raise ValueError("duplicate reservation IDs")
            for item in all_reservations:
                if item.reserved.llm_calls > 0 and item.reserved.cost_cny is None:
                    raise ValueError("invalid restored LLM reservation")
                controller._check_hard_limits([item.reserved])
            controller._reservations = {
                item.reservation_id: item for item in restored_reservations
            }
            controller._expired_reservations = {
                item.reservation_id: item for item in restored_expired
            }
            all_reservation_ids = {
                item.reservation_id for item in all_reservations
            }
            expired_ids = {item.reservation_id for item in restored_expired}
            if version in {3, 4}:
                assert isinstance(dispatched_reservation_ids, list)
                if (
                    any(
                        not isinstance(reservation_id, str)
                        for reservation_id in dispatched_reservation_ids
                    )
                    or len(set(dispatched_reservation_ids))
                    != len(dispatched_reservation_ids)
                ):
                    raise ValueError("invalid dispatched reservation IDs")
                restored_dispatched = set(dispatched_reservation_ids)
                if (
                    not restored_dispatched <= all_reservation_ids
                    or not expired_ids <= restored_dispatched
                ):
                    raise ValueError("invalid dispatched reservation IDs")
            else:
                restored_dispatched = {
                    item.reservation_id for item in restored_reservations
                }
            controller._dispatched_reservations = restored_dispatched
            controller._committed = []
            controller._committed_actions = []
            controller._committed_provenance = []
            for raw in committed:
                if not isinstance(raw, Mapping) or not isinstance(raw.get("action"), str):
                    raise ValueError("invalid committed usage state")
                action = raw["action"]
                usage = UsageActual.model_validate(raw.get("usage"))
                provenance: CommittedProvenance = None
                if version == 4:
                    raw_reservation = raw.get("reservation")
                    raw_mode = raw.get("mode")
                    component_index = raw.get("component_index")
                    if (
                        raw_reservation is None
                        and raw_mode is None
                        and component_index is None
                    ):
                        provenance = None
                    else:
                        if (
                            raw_mode not in {"settled", "failed"}
                            or type(component_index) is not int
                            or component_index < 0
                        ):
                            raise ValueError("invalid committed usage provenance")
                        provenance_reservation = BudgetReservation.model_validate(
                            raw_reservation
                        )
                        if provenance_reservation.action != action:
                            raise ValueError("invalid committed usage provenance")
                        provenance = (
                            provenance_reservation,
                            raw_mode,
                            component_index,
                        )
                controller._committed_actions.append(action)
                controller._committed.append(usage)
                controller._committed_provenance.append(provenance)
            controller._terminal_outcomes = {}
            for raw in terminal_outcomes:
                if not isinstance(raw, Mapping):
                    raise ValueError("invalid terminal outcome")
                terminal_reservation = BudgetReservation.model_validate(
                    raw.get("reservation")
                )
                mode = raw.get("mode")
                if mode not in {"settled", "failed"}:
                    raise ValueError("invalid terminal outcome")
                if raw.get("action") != terminal_reservation.action:
                    raise ValueError("invalid terminal outcome")
                terminal_actual = UsageActual.model_validate(raw.get("actual"))
                raw_components = raw.get("components")
                if not isinstance(raw_components, list) or not raw_components:
                    raise ValueError("invalid terminal outcome")
                components = tuple(
                    UsageActual.model_validate(component)
                    for component in raw_components
                )
                aggregate = UsageActual.model_validate(
                    _aggregate(components).model_dump()
                )
                if aggregate != terminal_actual:
                    raise ValueError("invalid terminal outcome")
                if mode == "settled" and len(components) != 1:
                    raise ValueError("invalid terminal outcome")
                if mode == "failed" and not fail_closed:
                    raise ValueError("invalid terminal outcome")
                reservation_id = terminal_reservation.reservation_id
                if (
                    reservation_id in controller._terminal_outcomes
                    or reservation_id in all_reservation_ids
                ):
                    raise ValueError("invalid terminal outcome")
                controller._terminal_outcomes[reservation_id] = (
                    terminal_reservation,
                    mode,
                    terminal_actual,
                    components,
                )
            if version == 4:
                committed_components = Counter(
                    _committed_component_key(action, usage, provenance)
                    for action, usage, provenance in zip(
                        controller._committed_actions,
                        controller._committed,
                        controller._committed_provenance,
                        strict=True,
                    )
                    if provenance is not None
                )
                receipt_components = Counter(
                    _committed_component_key(
                        reservation.action,
                        component,
                        (reservation, mode, index),
                    )
                    for reservation, mode, _, components in controller._terminal_outcomes.values()
                    for index, component in enumerate(components)
                )
                if committed_components != receipt_components:
                    raise ValueError("invalid terminal outcome")
                has_unreceipted = any(
                    provenance is None
                    for provenance in controller._committed_provenance
                )
                if terminal_outcomes_complete == has_unreceipted:
                    raise ValueError("invalid terminal outcome")
            if (
                formal_live
                and not fail_closed
                and any(usage.cost_cny is None for usage in controller._committed)
            ):
                raise ValueError("invalid formal-live committed usage")
            active_usage = [
                item.reserved for item in controller._reservations.values()
            ]
            if fail_closed:
                controller._check_hard_limits(active_usage)
            else:
                controller._check_hard_limits(
                    [*controller._committed, *active_usage]
                )
            controller._fail_closed = fail_closed
        except (BudgetExceededError, TypeError, ValueError):
            raise ValueError("invalid budget controller state") from None
        controller._expire_locked()
        return controller

    def _expire_locked(self) -> list[str]:
        now = self._clock()
        expired = [
            reservation_id
            for reservation_id, reservation in self._reservations.items()
            if reservation.expires_at <= now
        ]
        for reservation_id in expired:
            reservation = self._reservations.pop(reservation_id)
            if reservation_id in self._dispatched_reservations:
                self._expired_reservations[reservation_id] = reservation
            else:
                self._dispatched_reservations.discard(reservation_id)
        return sorted(expired)

    def _check_hard_limits(self, usages: list[UsageEstimate]) -> None:
        total = _aggregate(usages)
        checks = (
            (
                total.search_api_calls,
                self._budget.max_search_api_calls,
                "search API calls",
            ),
            (total.llm_calls, self._budget.max_llm_calls, "LLM calls"),
            (
                total.input_tokens + total.output_tokens,
                self._budget.max_total_tokens,
                "total tokens",
            ),
            (
                total.elapsed_ms,
                self._budget.max_elapsed_seconds * 1000,
                "elapsed time",
            ),
        )
        for value, limit, label in checks:
            if value > limit:
                raise BudgetExceededError(f"{label} hard limit exceeded: {value} > {limit}")
        known_cost = _known_cost(usages)
        cost_limit = Decimal(str(self._budget.max_cost_cny))
        if known_cost > cost_limit:
            raise BudgetExceededError(
                f"cost hard limit exceeded: {known_cost} > {cost_limit}"
            )

    @staticmethod
    def _ensure_within_reservation(reserved: UsageEstimate, actual: UsageActual) -> None:
        checks = (
            (actual.search_api_calls, reserved.search_api_calls, "search_api_calls"),
            (actual.llm_calls, reserved.llm_calls, "llm_calls"),
            (actual.input_tokens, reserved.input_tokens, "input_tokens"),
            (actual.output_tokens, reserved.output_tokens, "output_tokens"),
        )
        # elapsed_ms is intentionally soft: network latency varies beyond any
        # estimate, and the query-level max_elapsed hard limit still enforces
        # the total. A per-reservation elapsed overrun must not fail the settle
        # (which would fail-closed the whole query).
        for value, limit, label in checks:
            if value > limit:
                raise ReservationError(f"actual {label} exceeds its reservation")
        if (
            reserved.cost_cny is not None
            and actual.cost_cny is not None
            and actual.cost_cny > reserved.cost_cny
        ):
            raise ReservationError("actual cost_cny exceeds its reservation")
