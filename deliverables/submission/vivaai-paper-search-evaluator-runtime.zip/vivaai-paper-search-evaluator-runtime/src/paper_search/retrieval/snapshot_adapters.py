"""Priced live capture and structurally offline replay for search providers."""

from __future__ import annotations

import asyncio
import hashlib
import json
import random
import time
from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any, Literal, Protocol, TypedDict, TypeVar
from urllib.parse import quote

import httpx

from paper_search.application.contracts import SnapshotRef
from paper_search.control.pricing import ActualCostPricer
from paper_search.domain.models import (
    BudgetReservation,
    CitationEdge,
    CitationExpansion,
    ErrorDetail,
    Paper,
    ProviderName,
    ProviderPaperId,
    ProviderResult,
    UsageActual,
)
from paper_search.errors import ProtectedExecutionError
from paper_search.live_identity import LiveDependencyEvidence, LiveProviderDescriptor
from paper_search.retrieval.openalex import (
    OPENALEX_SELECT_FIELDS,
    _filter_expression,
    canonicalize_openalex_search_query,
    decode_openalex_page,
)
from paper_search.retrieval.semantic_scholar import (
    _FIELDS,
    _semantic_scholar_search_filters,
    decode_semantic_scholar_batch,
    decode_semantic_scholar_expansion,
    decode_semantic_scholar_search,
)
from paper_search.storage.cache import SAFE_RESPONSE_HEADERS
from paper_search.storage.dependency_snapshot import (
    DependencyCaptureStore,
    DependencyRequestIdentity,
    DependencySnapshotReader,
    SnapshotErrorV2,
)


Clock = Callable[[], datetime]
Sleep = Callable[[float], Awaitable[None]]
Jitter = Callable[[], float]
Method = Literal["GET", "POST"]
Operation = Literal["search", "batch", "references", "citations"]
QueryValue = str | int | float | bool | None


class SearchAttemptQuotaExceededError(RuntimeError):
    """A local hard quota rejected an attempt before network dispatch."""


class SearchAttemptGate(Protocol):
    def claim_attempt(self) -> int:
        """Irreversibly reserve one provider request before dispatch."""
        ...

_BASE_URLS = {
    "openalex": "https://api.openalex.org",
    "semantic_scholar": "https://api.semanticscholar.org/graph/v1",
}
_ADAPTERS = {
    "openalex": "openalex-works-v1",
    "semantic_scholar": "semantic-graph-v1",
}


class _LiveDescriptorSurface(TypedDict):
    provider: str
    version: str
    model: str | None
    endpoints: tuple[str, ...]
    operations: tuple[str, ...]


_LIVE_DESCRIPTOR_SURFACES: dict[ProviderName, _LiveDescriptorSurface] = {
    "openalex": {
        "provider": "openalex",
        "version": "live-capture-search-v1",
        "model": None,
        "endpoints": ("https://api.openalex.org/works",),
        "operations": ("search", "references", "citations"),
    },
    "semantic_scholar": {
        "provider": "semantic_scholar",
        "version": "live-capture-search-v1",
        "model": None,
        "endpoints": (
            "https://api.semanticscholar.org/graph/v1/paper/search",
            "https://api.semanticscholar.org/graph/v1/paper/batch",
            "https://api.semanticscholar.org/graph/v1/paper/{paper_id}/references",
            "https://api.semanticscholar.org/graph/v1/paper/{paper_id}/citations",
        ),
        "operations": ("search", "batch", "references", "citations"),
    },
}


@dataclass(frozen=True, slots=True)
class _SearchTransportConfig:
    dependency: ProviderName
    adapter: str
    base_url: str
    descriptor: LiveProviderDescriptor

    def canonical_bytes(self) -> bytes:
        return json.dumps(
            {
                "adapter": self.adapter,
                "base_url": self.base_url,
                "dependency": self.dependency,
                "descriptor": self.descriptor.model_dump(mode="json"),
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _sha256(value: bytes) -> str:
    return f"sha256:{hashlib.sha256(value).hexdigest()}"


def _aggregate_hash(hashes: list[str]) -> str:
    if not hashes:
        return _sha256(b"")
    if len(hashes) == 1:
        return hashes[0]
    return _sha256(json.dumps(hashes, separators=(",", ":")).encode("utf-8"))


def _snapshot_provenance(refs: list[SnapshotRef]) -> str:
    return json.dumps(
        [ref.model_dump(mode="json") for ref in refs],
        ensure_ascii=False,
        separators=(",", ":"),
    )


class ProviderSettlementController(Protocol):
    @property
    def policy_fingerprint(self) -> str: ...

    @property
    def formal_live(self) -> bool: ...

    def mark_dispatched(self, reservation: BudgetReservation) -> None: ...

    def settle(self, reservation: BudgetReservation, actual: UsageActual) -> None: ...

    def fail_closed(
        self,
        reservation: BudgetReservation,
        actual: UsageActual,
    ) -> None: ...


class ProviderAdapterError(ProtectedExecutionError):
    """A fixed, credential-safe terminal adapter failure."""

    search_error_code = "dependency_failure"


@dataclass(frozen=True)
class _RequestOutcome:
    content: bytes | None
    calls: int
    error: ErrorDetail | None
    captured_at: datetime
    safe_headers: dict[str, str]
    error_response_bytes: bytes = b""


ResultT = TypeVar("ResultT")


def _aggregate_attempts(attempts: list[UsageActual]) -> UsageActual:
    costs = [attempt.cost_cny for attempt in attempts]
    cost = (
        None
        if any(value is None for value in costs)
        else sum((value for value in costs if value is not None), Decimal("0"))
    )
    return UsageActual(
        search_api_calls=sum(item.search_api_calls for item in attempts),
        llm_calls=sum(item.llm_calls for item in attempts),
        input_tokens=sum(item.input_tokens for item in attempts),
        cached_input_tokens=sum(item.cached_input_tokens for item in attempts),
        uncached_input_tokens=sum(item.uncached_input_tokens for item in attempts),
        output_tokens=sum(item.output_tokens for item in attempts),
        cost_cny=cost,
        elapsed_ms=sum(item.elapsed_ms for item in attempts),
    )


def _terminal_usage(operation: _LiveOperation) -> UsageActual:
    """Return the exact usage the operation would settle for its attempts."""
    if operation.attempts:
        return _aggregate_attempts(operation.attempts)
    return UsageActual(cost_cny=Decimal("0"))


class _LiveOperation:
    """Track one reservation from first dispatch to exactly one terminal action."""

    def __init__(self, provider: LiveCaptureSearchProvider, reservation: BudgetReservation) -> None:
        self.provider = provider
        self.reservation = reservation
        duration = max(0.0, (reservation.expires_at - provider._clock()).total_seconds())
        self.deadline = asyncio.get_running_loop().time() + duration
        self.attempts: list[UsageActual] = []
        self._attempt_started: float | None = None
        self.terminal = False

    @property
    def dispatched(self) -> bool:
        return bool(self.attempts) or self._attempt_started is not None

    def remaining_seconds(self) -> float:
        return max(0.0, self.deadline - asyncio.get_running_loop().time())

    def start_attempt(self) -> None:
        if self._attempt_started is not None:
            raise RuntimeError("provider attempt is already in flight")
        self.provider._controller.mark_dispatched(self.reservation)
        self._attempt_started = time.perf_counter()

    def finish_attempt(self) -> UsageActual:
        if self._attempt_started is None:
            raise RuntimeError("provider attempt is not in flight")
        measured = UsageActual(
            search_api_calls=1,
            elapsed_ms=max(
                0,
                round((time.perf_counter() - self._attempt_started) * 1000),
            ),
        )
        self._attempt_started = None
        self.attempts.append(measured)
        valued = self.provider._pricer.value_actual(
            dependency=self.provider._dependency,
            model_or_adapter=self.provider._adapter,
            usage=measured,
        )
        self.attempts[-1] = valued
        return valued

    def retain_in_flight_unknown(self) -> None:
        if self._attempt_started is None:
            return
        measured = UsageActual(
            search_api_calls=1,
            elapsed_ms=max(
                0,
                round((time.perf_counter() - self._attempt_started) * 1000),
            ),
        )
        self._attempt_started = None
        self.attempts.append(measured)

    def settle(self) -> UsageActual:
        actual = (
            _aggregate_attempts(self.attempts)
            if self.attempts
            else UsageActual(cost_cny=Decimal("0"))
        )
        try:
            self.provider._controller.settle(self.reservation, actual)
        except Exception:
            self.fail_closed()
            raise
        self.terminal = True
        return actual

    def fail_closed(self) -> None:
        if self.terminal or not self.dispatched:
            return
        self.retain_in_flight_unknown()
        terminal_attempts = list(self.attempts)
        batch = getattr(self.provider._controller, "fail_closed_attempts", None)
        try:
            if callable(batch):
                batch(self.reservation, terminal_attempts)
            else:
                self.provider._controller.fail_closed(
                    self.reservation,
                    _aggregate_attempts(terminal_attempts),
                )
        finally:
            self.terminal = True


def _error(
    dependency: ProviderName,
    code: str,
    message: str,
    *,
    retryable: bool,
    request_id: str | None = None,
) -> ErrorDetail:
    return ErrorDetail(
        code=code,
        message=message,
        retryable=retryable,
        provider=dependency,
        request_id=request_id,
    )


def _key_quota_exhausted(response: httpx.Response) -> bool:
    """Return True when the used OpenAlex key cannot afford another search.

    OpenAlex list requests cost 10 credits. When the daily balance drops below
    that, responses 429 with ``x-ratelimit-remaining`` set to the leftover
    (positive) balance, so ``<= 0`` alone would never trigger rotation.
    """
    remaining = response.headers.get("x-ratelimit-remaining")
    if remaining is not None:
        try:
            return int(remaining) < 10
        except (TypeError, ValueError):
            pass
    try:
        payload = response.json()
    except ValueError:
        return False
    if not isinstance(payload, dict):
        return False
    message = payload.get("message")
    if not isinstance(message, str) or "insufficient budget" not in message.casefold():
        return False
    balances = (
        payload.get("dailyRemainingUsd"),
        payload.get("creditsRemaining"),
    )
    return any(
        not isinstance(value, bool)
        and isinstance(value, (int, float))
        and value <= 0
        for value in balances
    )


def _attempt_timeout(remaining_seconds: float, read_timeout: float | None) -> float:
    """Bound one HTTP attempt by the configured read timeout as well as the deadline."""
    if read_timeout is None or read_timeout <= 0:
        return remaining_seconds
    return min(remaining_seconds, read_timeout)


def _status_error(
    dependency: ProviderName,
    status_code: int,
    request_id: str | None,
) -> ErrorDetail:
    if status_code == 429:
        return _error(
            dependency,
            "rate_limited",
            f"{dependency} request was rate limited",
            retryable=True,
            request_id=request_id,
        )
    if 500 <= status_code <= 599:
        return _error(
            dependency,
            "server_error",
            f"{dependency} provider failed",
            retryable=True,
            request_id=request_id,
        )
    if status_code in {401, 403}:
        code, message = "authentication_error", f"{dependency} authentication failed"
    elif status_code == 400:
        code, message = "invalid_request", f"{dependency} request was rejected"
    else:
        code, message = "provider_error", f"{dependency} provider rejected the request"
    return _error(
        dependency,
        code,
        message,
        retryable=False,
        request_id=request_id,
    )


def _identity(
    *,
    dependency: ProviderName,
    operation: Operation,
    method: Method,
    endpoint: str,
    adapter: str,
    canonical_request: Mapping[str, object],
) -> DependencyRequestIdentity:
    return DependencyRequestIdentity.from_canonical_request(
        dependency=dependency,
        operation=operation,
        method=method,
        endpoint=endpoint,
        model_or_adapter=adapter,
        canonical_request=canonical_request,
    )


class LiveCaptureSearchProvider:
    """Issue bounded provider requests, price them, and capture successful bytes."""

    def __init__(
        self,
        *,
        dependency: ProviderName,
        client: httpx.AsyncClient,
        capture_store: DependencyCaptureStore,
        pricer: ActualCostPricer,
        controller: ProviderSettlementController,
        api_key: str | None = None,
        additional_api_keys: Sequence[str] = (),
        mailto: str | None = None,
        adapter_version: str | None = None,
        clock: Clock = _utc_now,
        sleep: Sleep | None = None,
        jitter: Jitter = random.random,
        minimum_request_interval_seconds: float = 0.0,
        attempt_gate: SearchAttemptGate | None = None,
    ) -> None:
        if controller.formal_live is not True:
            raise ValueError("live capture requires formal-live budget enforcement")
        if minimum_request_interval_seconds < 0:
            raise ValueError("minimum request interval must not be negative")
        if attempt_gate is not None and dependency != "openalex":
            raise ValueError("attempt gate is only supported for OpenAlex")
        self._client = client
        self._capture_store = capture_store
        self._pricer = pricer
        self._controller = controller
        keys: list[str] = []
        if api_key:
            keys.append(api_key)
        for key in additional_api_keys:
            if key and key not in keys:
                keys.append(key)
        self._api_keys = tuple(keys)
        self._key_cursor = 0
        self._openalex_quota_exhausted = False
        self._api_key = api_key
        self._mailto = mailto
        adapter = adapter_version or _ADAPTERS[dependency]
        surface = _LIVE_DESCRIPTOR_SURFACES[dependency]
        descriptor = LiveProviderDescriptor(
            identity_schema_version="live-provider-descriptor-v1",
            provider=surface["provider"],
            dependency=dependency,
            adapter=adapter,
            version=surface["version"],
            model=surface["model"],
            endpoints=surface["endpoints"],
            operations=surface["operations"],
        )
        self._transport_config = _SearchTransportConfig(
            dependency=dependency,
            adapter=adapter,
            base_url=_BASE_URLS[dependency],
            descriptor=descriptor,
        )
        self._transport_config_sha256 = _sha256(
            self._transport_config.canonical_bytes()
        )
        self._live_identity_evidence = LiveDependencyEvidence(
            identity_schema_version="live-dependency-evidence-v1",
            provider=descriptor,
            pricing_policy_sha256=pricer.policy_sha256,
            controller_policy_sha256=controller.policy_fingerprint,
            formal_live=True,
        )
        self._clock = clock
        self._sleep = sleep or asyncio.sleep
        self._jitter = jitter
        self._minimum_request_interval_seconds = minimum_request_interval_seconds
        self._attempt_gate = attempt_gate
        self._request_pacing_lock = asyncio.Lock()

    @property
    def live_identity_evidence(self) -> LiveDependencyEvidence:
        self._validated_transport_config()
        return self._live_identity_evidence

    def _validated_transport_config(self) -> _SearchTransportConfig:
        config = self._transport_config
        if _sha256(config.canonical_bytes()) != self._transport_config_sha256:
            raise ValueError("search transport configuration was modified")
        return config

    @property
    def _dependency(self) -> ProviderName:
        return self._validated_transport_config().dependency

    @property
    def _adapter(self) -> str:
        return self._validated_transport_config().adapter

    @property
    def live_pricer(self) -> ActualCostPricer:
        return self._pricer

    @property
    def live_controller(self) -> ProviderSettlementController:
        return self._controller

    def owns_live_resources(
        self, *, client: httpx.AsyncClient, capture_store: DependencyCaptureStore
    ) -> bool:
        """Prove that identity, dispatch, capture, and lifecycle share exact objects."""
        return self._client is client and self._capture_store is capture_store

    async def _run_live(
        self,
        reservation: BudgetReservation,
        call: Callable[[_LiveOperation], Awaitable[ResultT]],
    ) -> ResultT:
        operation = _LiveOperation(self, reservation)
        try:
            return await call(operation)
        except asyncio.CancelledError as cancellation:
            operation.fail_closed()
            raise cancellation from None
        except Exception as error:
            if not operation.dispatched:
                raise
            operation.fail_closed()
            error_type = type(error).__name__
            raise ProviderAdapterError(
                f"provider live capture failed ({error_type})"
            ) from None

    async def _request(
        self,
        *,
        method: Method,
        endpoint: str,
        params: Mapping[str, QueryValue],
        operation: _LiveOperation,
        body: Mapping[str, object] | None = None,
        remaining_calls: int,
    ) -> _RequestOutcome:
        captured_at = self._clock()
        if self._dependency == "openalex" and self._openalex_quota_exhausted:
            return _RequestOutcome(
                content=None,
                calls=0,
                error=_error(
                    "openalex",
                    "quota_exhausted",
                    "openalex daily key budget exhausted",
                    retryable=False,
                ),
                captured_at=captured_at,
                safe_headers={},
            )
        retry_capacity = (
            max(3, len(self._api_keys)) if self._dependency == "openalex" else 3
        )
        attempts_allowed = min(retry_capacity, max(0, remaining_calls))
        if attempts_allowed == 0:
            return _RequestOutcome(
                content=None,
                calls=0,
                error=_error(
                    self._dependency,
                    "budget_exhausted",
                    f"{self._dependency} reservation exhausted",
                    retryable=False,
                ),
                captured_at=captured_at,
                safe_headers={},
            )
        headers = {"Accept": "application/json"}
        request_params = dict(params)
        if self._dependency == "openalex":
            if self._api_keys:
                request_params["api_key"] = self._api_keys[self._key_cursor]
        elif self._api_key:
            headers["x-api-key"] = self._api_key
        if self._dependency == "openalex" and self._mailto:
            request_params["mailto"] = self._mailto

        last_error: ErrorDetail | None = None
        error_response_bytes = b""
        attempts_made = 0
        for retry_index in range(attempts_allowed):
            remaining_seconds = operation.remaining_seconds()
            if remaining_seconds <= 0:
                last_error = _error(
                    self._dependency,
                    "budget_exhausted",
                    f"{self._dependency} request deadline expired",
                    retryable=False,
                )
                break
            configured_read = self._client.timeout.read
            attempt_timeout = _attempt_timeout(
                remaining_seconds,
                (
                    float(configured_read)
                    if isinstance(configured_read, (int, float))
                    else None
                ),
            )
            try:
                async with asyncio.timeout(attempt_timeout):
                    async with self._request_pacing_lock:
                        if self._attempt_gate is not None:
                            self._attempt_gate.claim_attempt()
                        operation.start_attempt()
                        attempts_made += 1
                        try:
                            response = await self._client.request(
                                method,
                                f"{self._validated_transport_config().base_url}{endpoint}",
                                params=request_params,
                                json=body,
                                headers=headers,
                                follow_redirects=False,
                                timeout=attempt_timeout,
                            )
                        finally:
                            await self._pace_after_attempt()
            except SearchAttemptQuotaExceededError:
                last_error = _error(
                    self._dependency,
                    "budget_exhausted",
                    f"{self._dependency} daily key cap exhausted",
                    retryable=False,
                )
                break
            except (TimeoutError, httpx.TimeoutException):
                operation.finish_attempt()
                last_error = _error(
                    self._dependency,
                    "timeout",
                    f"{self._dependency} request timed out",
                    retryable=True,
                )
            except httpx.RequestError:
                operation.finish_attempt()
                last_error = _error(
                    self._dependency,
                    "network_error",
                    f"{self._dependency} network request failed",
                    retryable=False,
                )
            else:
                operation.finish_attempt()
                request_id = response.headers.get("x-request-id") or None
                if operation.remaining_seconds() <= 0:
                    last_error = _error(
                        self._dependency,
                        "timeout",
                        f"{self._dependency} request timed out",
                        retryable=True,
                    )
                elif response.status_code == 200:
                    safe_headers = {
                        name.casefold(): value
                        for name, value in response.headers.items()
                        if name.casefold() in SAFE_RESPONSE_HEADERS
                    }
                    return _RequestOutcome(
                        content=response.content,
                        calls=attempts_made,
                        error=None,
                        captured_at=captured_at,
                        safe_headers=safe_headers,
                    )
                else:
                    error_response_bytes = response.content
                    last_error = _status_error(
                        self._dependency,
                        response.status_code,
                        request_id,
                    )
            if (
                self._dependency == "openalex"
                and last_error is not None
                and last_error.code == "rate_limited"
                and _key_quota_exhausted(response)
            ):
                if self._rotate_key():
                    request_params["api_key"] = self._api_keys[self._key_cursor]
                    continue
                last_error = _error(
                    self._dependency,
                    "quota_exhausted",
                    "openalex daily key budget exhausted",
                    retryable=False,
                    request_id=last_error.request_id,
                )
                self._openalex_quota_exhausted = True
                break
            if (
                last_error is None
                or not last_error.retryable
                or retry_index + 1 >= attempts_allowed
            ):
                break
            if (
                self._dependency == "semantic_scholar"
                and last_error.code == "rate_limited"
            ):
                delay_seconds = 60.0 + self._jitter()
            else:
                delay_seconds = min(8, 2**retry_index) + self._jitter()
            remaining_seconds = operation.remaining_seconds()
            if delay_seconds >= remaining_seconds:
                last_error = _error(
                    self._dependency,
                    "timeout",
                    f"{self._dependency} request timed out",
                    retryable=True,
                )
                break
            async with asyncio.timeout(remaining_seconds):
                await self._sleep(delay_seconds)

        if last_error is None:
            raise RuntimeError("provider request ended without a terminal outcome")
        return _RequestOutcome(
            content=None,
            calls=attempts_made,
            error=last_error,
            captured_at=captured_at,
            safe_headers={},
            error_response_bytes=error_response_bytes,
        )

    async def _pace_after_attempt(self) -> None:
        if self._minimum_request_interval_seconds > 0:
            await self._sleep(self._minimum_request_interval_seconds)

    def _rotate_key(self) -> bool:
        if self._key_cursor + 1 >= len(self._api_keys):
            return False
        self._key_cursor += 1
        return True

    @staticmethod
    def _settle(operation: _LiveOperation) -> UsageActual:
        return operation.settle()

    def _capture(
        self,
        identity: DependencyRequestIdentity,
        outcome: _RequestOutcome,
    ) -> SnapshotRef:
        if outcome.content is None:
            raise RuntimeError("cannot capture an empty provider response")
        return self._capture_store.stage_success(
            identity,
            response_bytes=outcome.content,
            safe_headers=outcome.safe_headers,
            captured_at=outcome.captured_at,
        )

    def _capture_error(
        self,
        identity: DependencyRequestIdentity,
        outcome: _RequestOutcome,
    ) -> SnapshotRef:
        if outcome.error is None:
            raise RuntimeError("cannot capture a successful provider outcome as an error")
        return self._capture_store.stage_error(
            identity,
            error_code=outcome.error.code,
            message=outcome.error.message,
            retryable=outcome.error.retryable,
            response_bytes=outcome.error_response_bytes,
            safe_headers={},
            captured_at=outcome.captured_at,
        )

    async def search(
        self,
        query: str,
        filters: dict[str, object],
        limit: int,
        reservation: BudgetReservation,
    ) -> ProviderResult[list[Paper]]:
        if self._dependency == "openalex":
            return await self._run_live(
                reservation,
                lambda operation: self._openalex_search(
                    query, filters, limit, operation
                ),
            )
        return await self._run_live(
            reservation,
            lambda operation: self._semantic_search(
                query, filters, limit, operation
            ),
        )

    async def search_continuation(
        self,
        query: str,
        filters: dict[str, object],
        *,
        cursor: str,
        limit: int,
        reservation: BudgetReservation,
    ) -> ProviderResult[list[Paper]]:
        """Fetch exactly one frozen OpenAlex lexical continuation page."""
        if self._dependency != "openalex":
            raise ValueError("search continuation is only supported for OpenAlex")
        return await self._run_live(
            reservation,
            lambda operation: self._openalex_search_continuation(
                query,
                filters,
                cursor=cursor,
                limit=limit,
                operation=operation,
            ),
        )

    async def _openalex_search_continuation(
        self,
        query: str,
        filters: dict[str, object],
        *,
        cursor: str,
        limit: int,
        operation: _LiveOperation,
    ) -> ProviderResult[list[Paper]]:
        normalized_query = canonicalize_openalex_search_query(query)
        if not normalized_query:
            raise ValueError("query must not be empty")
        if not isinstance(cursor, str) or not cursor.strip() or cursor == "*":
            raise ValueError("a frozen OpenAlex continuation cursor is required")
        if type(limit) is not int or not 1 <= limit <= 50:
            raise ValueError("continuation limit must be an integer between 1 and 50")
        provider_filters = dict(filters)
        search_mode = provider_filters.pop("_search_mode", "lexical")
        if search_mode != "lexical":
            raise ValueError("OpenAlex continuation requires lexical search mode")
        filter_value = _filter_expression(provider_filters)
        canonical: dict[str, object] = {
            "query": normalized_query,
            "filters": provider_filters,
            "limit": limit,
            "per_page": limit,
            "select": OPENALEX_SELECT_FIELDS,
            "cursor": cursor,
        }
        if filter_value is not None:
            canonical["filter"] = filter_value
        identity = _identity(
            dependency="openalex",
            operation="search",
            method="GET",
            endpoint="/works",
            adapter=self._adapter,
            canonical_request=canonical,
        )
        params: dict[str, QueryValue] = {
            "per_page": limit,
            "select": OPENALEX_SELECT_FIELDS,
            "cursor": cursor,
            "search": normalized_query,
        }
        if filter_value is not None:
            params["filter"] = filter_value
        started = time.perf_counter()
        requested_at = self._clock()
        outcome = await self._request(
            method="GET",
            endpoint="/works",
            params=params,
            operation=operation,
            remaining_calls=1,
        )
        refs: list[SnapshotRef] = []
        hashes: list[str] = []
        papers: list[Paper] = []
        errors: list[ErrorDetail] = []
        if outcome.error is not None:
            errors.append(outcome.error)
            refs.append(self._capture_error(identity, outcome))
        elif outcome.content is not None:
            refs.append(self._capture(identity, outcome))
            hashes.append(_sha256(outcome.content))
            try:
                decoded = decode_openalex_page(outcome.content, limit=limit)
            except ValueError:
                errors.append(
                    _error(
                        "openalex",
                        "invalid_response",
                        "OpenAlex returned an invalid response",
                        retryable=False,
                    )
                )
            else:
                papers.extend(decoded.papers)
                errors.extend(decoded.errors)
        if refs:
            self._capture_store.annotate_usage(
                refs[0].entry_id,
                _terminal_usage(operation),
            )
        usage = self._settle(operation)
        elapsed_ms = max(0, round((time.perf_counter() - started) * 1000))
        return ProviderResult[list[Paper]](
            data=papers,
            usage=usage,
            provenance={
                "provider": "openalex",
                "endpoint": "/works",
                "model_id": self._adapter,
                "requested_at": requested_at.isoformat(),
                "response_hash": _aggregate_hash(hashes),
                "snapshot_refs": _snapshot_provenance(refs),
                "continuation_only": "true",
                "continuation_rank_offset": "50",
            },
            cache_hit=False,
            latency_ms=elapsed_ms,
            errors=errors,
        )

    async def _openalex_search(
        self,
        query: str,
        filters: dict[str, object],
        limit: int,
        operation: _LiveOperation,
    ) -> ProviderResult[list[Paper]]:
        normalized_query = canonicalize_openalex_search_query(query)
        if not normalized_query:
            raise ValueError("query must not be empty")
        if type(limit) is not int or not 1 <= limit <= 300:
            raise ValueError("limit must be an integer between 1 and 300")
        provider_filters = dict(filters)
        search_mode = provider_filters.pop("_search_mode", "lexical")
        if search_mode not in {"lexical", "semantic"}:
            raise ValueError("OpenAlex search mode must be lexical or semantic")
        if search_mode == "semantic" and limit > 50:
            raise ValueError("OpenAlex semantic search limit cannot exceed 50")
        filter_value = _filter_expression(provider_filters)
        started = time.perf_counter()
        requested_at = self._clock()
        cursor: str | None = None if search_mode == "semantic" else "*"
        seen_cursors: set[str] = set()
        raw_seen = 0
        calls = 0
        papers: list[Paper] = []
        errors: list[ErrorDetail] = []
        refs: list[SnapshotRef] = []
        hashes: list[str] = []
        while raw_seen < limit:
            if cursor is not None and cursor in seen_cursors:
                errors.append(
                    _error(
                        "openalex",
                        "pagination_cycle",
                        "OpenAlex returned a repeated page cursor",
                        retryable=False,
                    )
                )
                break
            if cursor is not None:
                seen_cursors.add(cursor)
            remaining = limit - raw_seen
            canonical: dict[str, object] = {
                "query": normalized_query,
                "filters": provider_filters,
                "limit": limit,
                "per_page": min(50, remaining),
                "select": OPENALEX_SELECT_FIELDS,
            }
            if search_mode == "semantic":
                canonical["search_mode"] = search_mode
                canonical["page"] = 1
            else:
                canonical["cursor"] = cursor or "*"
            if filter_value is not None:
                canonical["filter"] = filter_value
            identity = _identity(
                dependency="openalex",
                operation="search",
                method="GET",
                endpoint="/works",
                adapter=self._adapter,
                canonical_request=canonical,
            )
            params: dict[str, QueryValue] = {
                "per_page": min(50, remaining),
                "select": OPENALEX_SELECT_FIELDS,
            }
            if search_mode == "semantic":
                params["page"] = 1
            else:
                params["cursor"] = cursor or "*"
            params[
                "search.semantic" if search_mode == "semantic" else "search"
            ] = normalized_query
            if filter_value is not None:
                params["filter"] = filter_value
            outcome = await self._request(
                method="GET",
                endpoint="/works",
                params=params,
                operation=operation,
                remaining_calls=operation.reservation.reserved.search_api_calls - calls,
            )
            calls += outcome.calls
            if outcome.error is not None:
                errors.append(outcome.error)
                refs.append(self._capture_error(identity, outcome))
                break
            if outcome.content is None:
                break
            refs.append(self._capture(identity, outcome))
            hashes.append(_sha256(outcome.content))
            try:
                decoded = decode_openalex_page(outcome.content, limit=remaining)
            except ValueError:
                errors.append(
                    _error(
                        "openalex",
                        "invalid_response",
                        "OpenAlex returned an invalid response",
                        retryable=False,
                    )
                )
                break
            papers.extend(decoded.papers)
            errors.extend(decoded.errors)
            raw_seen += decoded.raw_count
            if (
                search_mode == "semantic"
                or decoded.raw_count == 0
                or decoded.next_cursor is None
            ):
                break
            cursor = decoded.next_cursor
        elapsed_ms = max(0, round((time.perf_counter() - started) * 1000))
        if refs:
            self._capture_store.annotate_usage(
                refs[0].entry_id,
                _terminal_usage(operation),
            )
        usage = self._settle(operation)
        return ProviderResult[list[Paper]](
            data=papers,
            usage=usage,
            provenance={
                "provider": "openalex",
                "endpoint": "/works",
                "model_id": self._adapter,
                "requested_at": requested_at.isoformat(),
                "response_hash": _aggregate_hash(hashes),
                "snapshot_refs": _snapshot_provenance(refs),
            },
            cache_hit=False,
            latency_ms=elapsed_ms,
            errors=errors,
        )

    async def _semantic_search(
        self,
        query: str,
        filters: dict[str, object],
        limit: int,
        operation: _LiveOperation,
    ) -> ProviderResult[list[Paper]]:
        normalized_query = " ".join(query.split())
        if not normalized_query:
            raise ValueError("query must not be empty")
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("limit must be an integer between 1 and 100")
        provider_filters, search_mode = _semantic_scholar_search_filters(filters)
        params: dict[str, QueryValue] = {
            "query": normalized_query,
            "limit": limit,
            "fields": _FIELDS,
        }
        canonical: dict[str, object] = {
            "query": normalized_query,
            "filters": provider_filters,
            "limit": limit,
            "fields": _FIELDS,
        }
        if search_mode == "semantic":
            canonical["search_mode"] = search_mode
        if provider_filters:
            year = (
                f"{provider_filters.get('year_from', '')}-"
                f"{provider_filters.get('year_to', '')}"
            )
            params["year"] = year
            canonical["year"] = year
        result = await self._semantic_papers_operation(
            request_operation="search",
            method="GET",
            endpoint="/paper/search",
            params=params,
            canonical=canonical,
            operation=operation,
            decode=lambda content: decode_semantic_scholar_search(
                content,
                limit=limit,
            ),
        )
        result.provenance["search_mode"] = search_mode
        return result

    async def batch_details(
        self,
        paper_ids: Sequence[str],
        reservation: BudgetReservation,
    ) -> ProviderResult[list[Paper]]:
        if self._dependency != "semantic_scholar":
            raise ValueError("batch details require Semantic Scholar")
        ids = [value.strip() for value in paper_ids if value.strip()]
        if not ids:
            raise ValueError("paper_ids must not be empty")
        return await self._run_live(
            reservation,
            lambda operation: self._batch_details_operation(ids, operation),
        )

    async def _batch_details_operation(
        self,
        ids: list[str],
        operation: _LiveOperation,
    ) -> ProviderResult[list[Paper]]:
        canonical = {"fields": _FIELDS, "ids": ids}
        return await self._semantic_papers_operation(
            request_operation="batch",
            method="POST",
            endpoint="/paper/batch",
            params={"fields": _FIELDS},
            canonical=canonical,
            operation=operation,
            body={"ids": ids},
            decode=decode_semantic_scholar_batch,
        )

    async def _semantic_papers_operation(
        self,
        *,
        request_operation: Literal["search", "batch"],
        method: Method,
        endpoint: str,
        params: Mapping[str, QueryValue],
        canonical: Mapping[str, object],
        operation: _LiveOperation,
        decode: Callable[[bytes], Any],
        body: Mapping[str, object] | None = None,
    ) -> ProviderResult[list[Paper]]:
        started = time.perf_counter()
        requested_at = self._clock()
        identity = _identity(
            dependency="semantic_scholar",
            operation=request_operation,
            method=method,
            endpoint=endpoint,
            adapter=self._adapter,
            canonical_request=canonical,
        )
        outcome = await self._request(
            method=method,
            endpoint=endpoint,
            params=params,
            body=body,
            operation=operation,
            remaining_calls=operation.reservation.reserved.search_api_calls,
        )
        papers: list[Paper] = []
        errors: list[ErrorDetail] = []
        refs: list[SnapshotRef] = []
        hashes: list[str] = []
        if outcome.error is not None:
            errors.append(outcome.error)
            refs.append(self._capture_error(identity, outcome))
        elif outcome.content is not None:
            refs.append(self._capture(identity, outcome))
            hashes.append(_sha256(outcome.content))
            decoded = decode(outcome.content)
            papers.extend(decoded.papers)
            errors.extend(decoded.errors)
        elapsed_ms = max(0, round((time.perf_counter() - started) * 1000))
        if refs:
            self._capture_store.annotate_usage(
                refs[0].entry_id,
                _terminal_usage(operation),
            )
        usage = self._settle(operation)
        return ProviderResult[list[Paper]](
            data=papers,
            usage=usage,
            provenance={
                "provider": "semantic_scholar",
                "endpoint": endpoint,
                "model_id": self._adapter,
                "requested_at": requested_at.isoformat(),
                "response_hash": _aggregate_hash(hashes),
                "snapshot_refs": _snapshot_provenance(refs),
            },
            cache_hit=False,
            latency_ms=elapsed_ms,
            errors=errors,
        )

    async def _expansion(
        self,
        *,
        direction: Literal["references", "citations"],
        paper_id: ProviderPaperId,
        limit: int,
        operation: _LiveOperation,
    ) -> ProviderResult[CitationExpansion]:
        if self._dependency == "openalex":
            return await self._openalex_expansion(
                direction=direction,
                paper_id=paper_id,
                limit=limit,
                operation=operation,
            )
        if self._dependency != "semantic_scholar":  # pragma: no cover - closed provider union
            raise ValueError("unsupported citation expansion provider")
        if paper_id.provider != "semantic_scholar":
            raise ValueError("citation expansion requires a Semantic Scholar paper ID")
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("limit must be an integer between 1 and 100")
        started = time.perf_counter()
        requested_at = self._clock()
        endpoint = f"/paper/{quote(paper_id.value, safe='')}/{direction}"
        canonical = {
            "fields": _FIELDS,
            "limit": limit,
            "offset": 0,
            "paper_id": paper_id.value,
        }
        identity = _identity(
            dependency="semantic_scholar",
            operation=direction,
            method="GET",
            endpoint=endpoint,
            adapter=self._adapter,
            canonical_request=canonical,
        )
        outcome = await self._request(
            method="GET",
            endpoint=endpoint,
            params={"fields": _FIELDS, "limit": limit, "offset": 0},
            operation=operation,
            remaining_calls=operation.reservation.reserved.search_api_calls,
        )
        expansion = CitationExpansion(papers=[], raw_edges=[])
        errors: list[ErrorDetail] = []
        refs: list[SnapshotRef] = []
        hashes: list[str] = []
        if outcome.error is not None:
            errors.append(outcome.error)
            refs.append(self._capture_error(identity, outcome))
        elif outcome.content is not None:
            refs.append(self._capture(identity, outcome))
            hashes.append(_sha256(outcome.content))
            if operation.remaining_seconds() <= 0:
                raise TimeoutError("provider deadline expired during capture")
            decoded = decode_semantic_scholar_expansion(
                outcome.content,
                direction=direction,
                paper_id=paper_id,
                limit=limit,
            )
            if operation.remaining_seconds() <= 0:
                raise TimeoutError("provider deadline expired during decode")
            expansion = decoded.expansion
            errors.extend(decoded.errors)
        elapsed_ms = max(0, round((time.perf_counter() - started) * 1000))
        if refs:
            self._capture_store.annotate_usage(
                refs[0].entry_id,
                _terminal_usage(operation),
            )
        usage = self._settle(operation)
        return ProviderResult[CitationExpansion](
            data=expansion,
            usage=usage,
            provenance={
                "provider": "semantic_scholar",
                "endpoint": endpoint,
                "model_id": self._adapter,
                "requested_at": requested_at.isoformat(),
                "response_hash": _aggregate_hash(hashes),
                "snapshot_refs": _snapshot_provenance(refs),
            },
            cache_hit=False,
            latency_ms=elapsed_ms,
            errors=errors,
        )

    async def _openalex_expansion(
        self,
        *,
        direction: Literal["references", "citations"],
        paper_id: ProviderPaperId,
        limit: int,
        operation: _LiveOperation,
    ) -> ProviderResult[CitationExpansion]:
        if paper_id.provider != "openalex":
            raise ValueError("OpenAlex expansion requires an OpenAlex paper ID")
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("OpenAlex expansion limit must be between 1 and 100")
        started = time.perf_counter()
        requested_at = self._clock()
        refs: list[SnapshotRef] = []
        hashes: list[str] = []
        errors: list[ErrorDetail] = []
        papers: list[Paper] = []
        calls = 0

        async def fetch(
            *,
            request_operation: Operation,
            endpoint: str,
            params: Mapping[str, QueryValue],
            canonical: Mapping[str, object],
        ) -> bytes | None:
            nonlocal calls
            identity = _identity(
                dependency="openalex",
                operation=request_operation,
                method="GET",
                endpoint=endpoint,
                adapter=self._adapter,
                canonical_request=canonical,
            )
            outcome = await self._request(
                method="GET",
                endpoint=endpoint,
                params=params,
                operation=operation,
                remaining_calls=(
                    operation.reservation.reserved.search_api_calls - calls
                ),
            )
            calls += outcome.calls
            if outcome.error is not None:
                errors.append(outcome.error)
                refs.append(self._capture_error(identity, outcome))
                return None
            if outcome.content is None:
                return None
            refs.append(self._capture(identity, outcome))
            hashes.append(_sha256(outcome.content))
            return outcome.content

        if direction == "references":
            endpoint = f"/works/{quote(paper_id.value, safe='')}"
            seed_bytes = await fetch(
                request_operation="references",
                endpoint=endpoint,
                params={"select": "id,referenced_works"},
                canonical={
                    "paper_id": paper_id.value,
                    "select": "id,referenced_works",
                },
            )
            reference_ids: list[str] = []
            if seed_bytes is not None:
                try:
                    seed_payload = json.loads(seed_bytes)
                except (UnicodeDecodeError, json.JSONDecodeError):
                    seed_payload = None
                raw_ids = (
                    seed_payload.get("referenced_works")
                    if isinstance(seed_payload, dict)
                    else None
                )
                if not isinstance(raw_ids, list):
                    errors.append(
                        _error(
                            "openalex",
                            "invalid_response",
                            "OpenAlex work lacks referenced_works",
                            retryable=False,
                        )
                    )
                else:
                    reference_ids = [
                        item.rsplit("/", 1)[-1]
                        for item in raw_ids
                        if isinstance(item, str) and item.rsplit("/", 1)[-1]
                    ][:limit]
            if reference_ids and not errors:
                filter_value = "openalex:" + "|".join(reference_ids)
                page_bytes = await fetch(
                    request_operation="references",
                    endpoint="/works",
                    params={
                        "filter": filter_value,
                        "per_page": len(reference_ids),
                        "select": OPENALEX_SELECT_FIELDS,
                    },
                    canonical={
                        "paper_id": paper_id.value,
                        "filter": filter_value,
                        "limit": limit,
                        "per_page": len(reference_ids),
                        "select": OPENALEX_SELECT_FIELDS,
                    },
                )
                if page_bytes is not None:
                    try:
                        decoded = decode_openalex_page(page_bytes, limit=limit)
                    except ValueError:
                        errors.append(
                            _error(
                                "openalex",
                                "invalid_response",
                                "OpenAlex returned invalid reference works",
                                retryable=False,
                            )
                        )
                    else:
                        papers.extend(decoded.papers)
                        errors.extend(decoded.errors)
        else:
            filter_value = f"cites:{paper_id.value}"
            page_bytes = await fetch(
                request_operation="citations",
                endpoint="/works",
                params={
                    "filter": filter_value,
                    "per_page": limit,
                    "select": OPENALEX_SELECT_FIELDS,
                },
                canonical={
                    "paper_id": paper_id.value,
                    "filter": filter_value,
                    "limit": limit,
                    "per_page": limit,
                    "select": OPENALEX_SELECT_FIELDS,
                },
            )
            if page_bytes is not None:
                try:
                    decoded = decode_openalex_page(page_bytes, limit=limit)
                except ValueError:
                    errors.append(
                        _error(
                            "openalex",
                            "invalid_response",
                            "OpenAlex returned invalid citing works",
                            retryable=False,
                        )
                    )
                else:
                    papers.extend(decoded.papers)
                    errors.extend(decoded.errors)

        edges = [
            CitationEdge(
                provider="openalex",
                citing_provider_id=(
                    paper_id
                    if direction == "references"
                    else ProviderPaperId(provider="openalex", value=paper.openalex_id or "")
                ),
                cited_provider_id=(
                    ProviderPaperId(provider="openalex", value=paper.openalex_id or "")
                    if direction == "references"
                    else paper_id
                ),
            )
            for paper in papers
            if paper.openalex_id is not None
        ]
        elapsed_ms = max(0, round((time.perf_counter() - started) * 1000))
        if refs:
            self._capture_store.annotate_usage(
                refs[0].entry_id,
                _terminal_usage(operation),
            )
        usage = self._settle(operation)
        return ProviderResult[CitationExpansion](
            data=CitationExpansion(papers=papers, raw_edges=edges),
            usage=usage,
            provenance={
                "provider": "openalex",
                "endpoint": "/works",
                "model_id": self._adapter,
                "requested_at": requested_at.isoformat(),
                "response_hash": _aggregate_hash(hashes),
                "snapshot_refs": _snapshot_provenance(refs),
            },
            cache_hit=False,
            latency_ms=elapsed_ms,
            errors=errors,
        )

    async def references(
        self,
        paper_id: ProviderPaperId,
        limit: int,
        reservation: BudgetReservation,
    ) -> ProviderResult[CitationExpansion]:
        return await self._run_live(
            reservation,
            lambda operation: self._expansion(
                direction="references",
                paper_id=paper_id,
                limit=limit,
                operation=operation,
            ),
        )

    async def citations(
        self,
        paper_id: ProviderPaperId,
        limit: int,
        reservation: BudgetReservation,
    ) -> ProviderResult[CitationExpansion]:
        return await self._run_live(
            reservation,
            lambda operation: self._expansion(
                direction="citations",
                paper_id=paper_id,
                limit=limit,
                operation=operation,
            ),
        )


class ReplaySearchProvider:
    """Decode sealed provider bytes without owning any network client."""

    def __init__(
        self,
        *,
        dependency: ProviderName,
        reader: DependencySnapshotReader,
        adapter_version: str | None = None,
        clock: Clock = _utc_now,
    ) -> None:
        self._dependency = dependency
        self._reader = reader
        self._adapter = adapter_version or _ADAPTERS[dependency]
        self._clock = clock

    def _read(
        self,
        identity: DependencyRequestIdentity,
    ) -> tuple[
        bytes | None,
        SnapshotRef | None,
        SnapshotErrorV2 | None,
        UsageActual | None,
    ]:
        try:
            snapshot = self._reader.read(identity)
        except KeyError:
            return None, None, None, None
        return (
            snapshot.response_bytes,
            snapshot.ref,
            snapshot.error,
            snapshot.usage,
        )

    def _snapshot_error(self, error: SnapshotErrorV2) -> ErrorDetail:
        return _error(
            self._dependency,
            error.code,
            error.message,
            retryable=error.retryable,
        )

    def _result(
        self,
        *,
        data: Any,
        endpoint: str,
        requested_at: datetime,
        hashes: list[str],
        refs: list[SnapshotRef],
        errors: list[ErrorDetail],
        usage: UsageActual | None = None,
    ) -> ProviderResult[Any]:
        return ProviderResult[Any](
            data=data,
            usage=usage or UsageActual(),
            provenance={
                "provider": self._dependency,
                "endpoint": endpoint,
                "model_id": self._adapter,
                "requested_at": requested_at.isoformat(),
                "response_hash": _aggregate_hash(hashes),
                "snapshot_refs": _snapshot_provenance(refs),
                "snapshot_set_id": self._reader.snapshot_set_id,
            },
            cache_hit=bool(refs),
            latency_ms=0,
            errors=errors,
        )

    def _miss(self) -> ErrorDetail:
        return _error(
            self._dependency,
            "snapshot_unavailable",
            f"{self._dependency} snapshot is unavailable",
            retryable=False,
        )

    async def search(
        self,
        query: str,
        filters: dict[str, object],
        limit: int,
        reservation: BudgetReservation,
    ) -> ProviderResult[list[Paper]]:
        del reservation
        if self._dependency == "openalex":
            return await self._openalex_search(query, filters, limit)
        return await self._semantic_search(query, filters, limit)

    async def _openalex_search(
        self,
        query: str,
        filters: dict[str, object],
        limit: int,
    ) -> ProviderResult[list[Paper]]:
        normalized_query = canonicalize_openalex_search_query(query)
        if not normalized_query:
            raise ValueError("query must not be empty")
        if type(limit) is not int or not 1 <= limit <= 300:
            raise ValueError("limit must be an integer between 1 and 300")
        provider_filters = dict(filters)
        search_mode = provider_filters.pop("_search_mode", "lexical")
        if search_mode not in {"lexical", "semantic"}:
            raise ValueError("OpenAlex search mode must be lexical or semantic")
        if search_mode == "semantic" and limit > 50:
            raise ValueError("OpenAlex semantic search limit cannot exceed 50")
        filter_value = _filter_expression(provider_filters)
        requested_at = self._clock()
        cursor: str | None = None if search_mode == "semantic" else "*"
        seen: set[str] = set()
        raw_seen = 0
        papers: list[Paper] = []
        errors: list[ErrorDetail] = []
        refs: list[SnapshotRef] = []
        hashes: list[str] = []
        usages: list[UsageActual] = []
        while raw_seen < limit:
            if cursor is not None and cursor in seen:
                errors.append(
                    _error(
                        "openalex",
                        "pagination_cycle",
                        "OpenAlex returned a repeated page cursor",
                        retryable=False,
                    )
                )
                break
            if cursor is not None:
                seen.add(cursor)
            remaining = limit - raw_seen
            canonical: dict[str, object] = {
                "query": normalized_query,
                "filters": provider_filters,
                "limit": limit,
                "per_page": min(50, remaining),
                "select": OPENALEX_SELECT_FIELDS,
            }
            if search_mode == "semantic":
                canonical["search_mode"] = search_mode
                canonical["page"] = 1
            else:
                canonical["cursor"] = cursor or "*"
            if filter_value is not None:
                canonical["filter"] = filter_value
            identity = _identity(
                dependency="openalex",
                operation="search",
                method="GET",
                endpoint="/works",
                adapter=self._adapter,
                canonical_request=canonical,
            )
            content, ref, error, usage = self._read(identity)
            if error is not None:
                errors.append(self._snapshot_error(error))
                if ref is not None:
                    refs.append(ref)
                if usage is not None:
                    usages.append(usage)
                break
            if content is None or ref is None:
                errors.append(self._miss())
                break
            refs.append(ref)
            hashes.append(_sha256(content))
            if usage is not None:
                usages.append(usage)
            try:
                decoded = decode_openalex_page(content, limit=remaining)
            except ValueError:
                errors.append(
                    _error(
                        "openalex",
                        "invalid_response",
                        "OpenAlex snapshot response is invalid",
                        retryable=False,
                    )
                )
                break
            papers.extend(decoded.papers)
            errors.extend(decoded.errors)
            raw_seen += decoded.raw_count
            if (
                search_mode == "semantic"
                or decoded.raw_count == 0
                or decoded.next_cursor is None
            ):
                break
            cursor = decoded.next_cursor
        return self._result(
            data=papers,
            endpoint="/works",
            requested_at=requested_at,
            hashes=hashes,
            refs=refs,
            errors=errors,
            usage=_aggregate_attempts(usages) if usages else None,
        )

    async def _semantic_search(
        self,
        query: str,
        filters: dict[str, object],
        limit: int,
    ) -> ProviderResult[list[Paper]]:
        normalized_query = " ".join(query.split())
        if not normalized_query:
            raise ValueError("query must not be empty")
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("limit must be an integer between 1 and 100")
        provider_filters, search_mode = _semantic_scholar_search_filters(filters)
        canonical: dict[str, object] = {
            "query": normalized_query,
            "filters": provider_filters,
            "limit": limit,
            "fields": _FIELDS,
        }
        if search_mode == "semantic":
            canonical["search_mode"] = search_mode
        if provider_filters:
            canonical["year"] = (
                f"{provider_filters.get('year_from', '')}-"
                f"{provider_filters.get('year_to', '')}"
            )
        identity = _identity(
            dependency="semantic_scholar",
            operation="search",
            method="GET",
            endpoint="/paper/search",
            adapter=self._adapter,
            canonical_request=canonical,
        )
        content, ref, error, usage = self._read(identity)
        errors: list[ErrorDetail] = []
        papers: list[Paper] = []
        refs: list[SnapshotRef] = []
        hashes: list[str] = []
        if error is not None:
            errors.append(self._snapshot_error(error))
            if ref is not None:
                refs.append(ref)
        elif content is None or ref is None:
            errors.append(self._miss())
        else:
            decoded = decode_semantic_scholar_search(content, limit=limit)
            papers = decoded.papers
            errors.extend(decoded.errors)
            refs.append(ref)
            hashes.append(_sha256(content))
        result = self._result(
            data=papers,
            endpoint="/paper/search",
            requested_at=self._clock(),
            hashes=hashes,
            refs=refs,
            errors=errors,
            usage=usage,
        )
        result.provenance["search_mode"] = search_mode
        return result

    async def batch_details(
        self,
        paper_ids: Sequence[str],
        reservation: BudgetReservation,
    ) -> ProviderResult[list[Paper]]:
        del reservation
        if self._dependency != "semantic_scholar":
            raise ValueError("batch details require Semantic Scholar")
        ids = [value.strip() for value in paper_ids if value.strip()]
        if not ids:
            raise ValueError("paper_ids must not be empty")
        identity = _identity(
            dependency="semantic_scholar",
            operation="batch",
            method="POST",
            endpoint="/paper/batch",
            adapter=self._adapter,
            canonical_request={"fields": _FIELDS, "ids": ids},
        )
        content, ref, error, usage = self._read(identity)
        errors: list[ErrorDetail] = []
        papers: list[Paper] = []
        refs: list[SnapshotRef] = []
        hashes: list[str] = []
        if error is not None:
            errors.append(self._snapshot_error(error))
            if ref is not None:
                refs.append(ref)
        elif content is None or ref is None:
            errors.append(self._miss())
        else:
            decoded = decode_semantic_scholar_batch(content)
            papers = decoded.papers
            errors.extend(decoded.errors)
            refs.append(ref)
            hashes.append(_sha256(content))
        return self._result(
            data=papers,
            endpoint="/paper/batch",
            requested_at=self._clock(),
            hashes=hashes,
            refs=refs,
            errors=errors,
            usage=usage,
        )

    async def _expansion(
        self,
        *,
        direction: Literal["references", "citations"],
        paper_id: ProviderPaperId,
        limit: int,
    ) -> ProviderResult[CitationExpansion]:
        if self._dependency != "semantic_scholar":
            raise ValueError("citation expansion requires Semantic Scholar")
        if paper_id.provider != "semantic_scholar":
            raise ValueError("citation expansion requires a Semantic Scholar paper ID")
        endpoint = f"/paper/{quote(paper_id.value, safe='')}/{direction}"
        identity = _identity(
            dependency="semantic_scholar",
            operation=direction,
            method="GET",
            endpoint=endpoint,
            adapter=self._adapter,
            canonical_request={
                "fields": _FIELDS,
                "limit": limit,
                "offset": 0,
                "paper_id": paper_id.value,
            },
        )
        content, ref, error, usage = self._read(identity)
        errors: list[ErrorDetail] = []
        expansion = CitationExpansion(papers=[], raw_edges=[])
        refs: list[SnapshotRef] = []
        hashes: list[str] = []
        if error is not None:
            errors.append(self._snapshot_error(error))
            if ref is not None:
                refs.append(ref)
        elif content is None or ref is None:
            errors.append(self._miss())
        else:
            decoded = decode_semantic_scholar_expansion(
                content,
                direction=direction,
                paper_id=paper_id,
                limit=limit,
            )
            expansion = decoded.expansion
            errors.extend(decoded.errors)
            refs.append(ref)
            hashes.append(_sha256(content))
        return self._result(
            data=expansion,
            endpoint=endpoint,
            requested_at=self._clock(),
            hashes=hashes,
            refs=refs,
            errors=errors,
            usage=usage,
        )

    async def references(
        self,
        paper_id: ProviderPaperId,
        limit: int,
        reservation: BudgetReservation,
    ) -> ProviderResult[CitationExpansion]:
        del reservation
        return await self._expansion(
            direction="references",
            paper_id=paper_id,
            limit=limit,
        )

    async def citations(
        self,
        paper_id: ProviderPaperId,
        limit: int,
        reservation: BudgetReservation,
    ) -> ProviderResult[CitationExpansion]:
        del reservation
        return await self._expansion(
            direction="citations",
            paper_id=paper_id,
            limit=limit,
        )


__all__ = [
    "LiveCaptureSearchProvider",
    "ProviderAdapterError",
    "ReplaySearchProvider",
]
